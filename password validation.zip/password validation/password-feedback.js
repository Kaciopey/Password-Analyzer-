// Select password input, feedback, and password strength bar
const passwordInput = document.getElementById("password");
const feedback = document.getElementById("password-feedback");
const strengthBar = document.getElementById("passwordStrengthBar");

// Event listener for password input
passwordInput.addEventListener("input", function() {
    const password = passwordInput.value;
    let strength = 0;

    // Check password length
    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/\d/.test(password)) strength++;
    if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) strength++;

    // Update feedback text and strength bar based on password strength
    if (strength === 1) {
        feedback.textContent = "Very Weak password.";
        feedback.style.color = "red";
        strengthBar.style.width = "20%";
        strengthBar.style.backgroundColor = "#FF0000"; // Red
    } else if (strength === 2) {
        feedback.textContent = "Weak password.";
        feedback.style.color = "orange";
        strengthBar.style.width = "40%";
        strengthBar.style.backgroundColor = "#FFA500"; // Orange
    } else if (strength === 3) {
        feedback.textContent = "Moderate password.";
        feedback.style.color = "yellow";
        strengthBar.style.width = "60%";
        strengthBar.style.backgroundColor = "#FFFF00"; // Yellow
    } else if (strength === 4) {
        feedback.textContent = "Strong password!";
        feedback.style.color = "green";
        strengthBar.style.width = "80%";
        strengthBar.style.backgroundColor = "#32CD32"; // Green
    } else if (strength === 5) {
        feedback.textContent = "Very Strong password!";
        feedback.style.color = "green";
        strengthBar.style.width = "100%";
        strengthBar.style.backgroundColor = "#008000"; // Dark green
    } else {
        feedback.textContent = "Password should be at least 8 characters.";
        feedback.style.color = "red";
        strengthBar.style.width = "0%";
        strengthBar.style.backgroundColor = "#e0e0e0"; // Light grey
    }
});

// Submit button event listener
document.getElementById("submitBtn").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission

    // Clear previous error messages
    clearValidationErrors();

    // Validate the form fields
    let isValid = validateForm();

    // If valid, alert success
    if (isValid) {
        alert("Form submitted successfully!");
    }
});

// Function to clear validation errors
function clearValidationErrors() {
    document.getElementById("usernameError").textContent = "";
    document.getElementById("passwordError").textContent = "";
    document.getElementById("confirmPasswordError").textContent = "";
    const errorElements = document.querySelectorAll(".error");
    errorElements.forEach((el) => el.textContent = "");
}

// Function to validate all fields
function validateForm() {
    let isValid = true;

    // Validate Username
    const username = document.getElementById("username").value;
    if (!username) {
        document.getElementById("usernameError").textContent = "Please enter username.";
        document.getElementById("usernameError").style.color = "red";
        isValid = false;
    } else {
        const usernamePattern = /^[a-z0-9]{4,12}$/;
        if (!usernamePattern.test(username)) {
            document.getElementById("usernameError").textContent = "Invalid username. Only lowercase letters or numbers (4-12 chars).";
            document.getElementById("usernameError").style.color = "orange";
            isValid = false;
        }
    }

    // Validate Password
    const password = document.getElementById("password").value;
    if (!password) {
        document.getElementById("passwordError").textContent = "Please enter password.";
        document.getElementById("passwordError").style.color = "red";
        isValid = false;
    } else {
        const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{9,}$/;
        if (!passwordPattern.test(password)) {
            document.getElementById("passwordError").textContent = "Password must be >8 chars and include 1 uppercase, 1 lowercase, 1 number, and 1 special char.";
            document.getElementById("passwordError").style.color = "orange";
            isValid = false;
        }
    }

    // Confirm Password validation
    const confirmPassword = document.getElementById("confirmPassword").value;
    if (password !== confirmPassword) {
        document.getElementById("confirmPasswordError").textContent = "Passwords do not match.";
        document.getElementById("confirmPasswordError").style.color = "red";
        isValid = false;
    }

    return isValid;
}
